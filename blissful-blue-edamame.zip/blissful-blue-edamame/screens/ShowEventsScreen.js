// ShowEventsScreen.js
import React, { useState, useEffect } from 'react';
import { View, Text, Button, FlatList } from 'react-native';

export default function ShowEventsScreen() {
  const [events, setEvents] = useState([]);

  useEffect(() => {
    fetchEvents();
  }, []);

  const fetchEvents = async () => {
    try {
      const response = await fetch('YOUR_API_ENDPOINT/event/get/');
      const data = await response.json();
      setEvents(data);
    } catch (error) {
      console.error('Error fetching events: ', error);
    }
  };

  const renderItem = ({ item }) => (
    <View style={{ padding: 10, margin: 5, backgroundColor: '#333', borderRadius: 5 }}>
      <Text style={{ color: 'white' }}>{item.event_description}</Text>
      <Text style={{ color: 'white' }}>{item.date_of_event}</Text>
    </View>
  );

  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Button title="Refresh" onPress={fetchEvents} />
      <FlatList
        data={events}
        renderItem={renderItem}
        keyExtractor={(item) => item.id.toString()}
      />
    </View>
  );
}
