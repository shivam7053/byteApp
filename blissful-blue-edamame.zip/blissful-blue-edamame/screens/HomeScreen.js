// HomeScreen.js
import React from 'react';
import { View, Text, Button } from 'react-native';

export default function HomeScreen({ navigation }) {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Welcome to the App!</Text>
      <Button
        title="Show Events"
        onPress={() => navigation.navigate('ShowEvents')}
      />
      <Button
        title="Create Event"
        onPress={() => navigation.navigate('CreateEvent')}
      />
    </View>
  );
}
