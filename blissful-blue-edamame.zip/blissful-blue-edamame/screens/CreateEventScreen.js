// CreateEventScreen.js
import React, { useState } from 'react';
import { View, Text, TextInput, Button, Alert } from 'react-native';

export default function CreateEventScreen() {
  const [eventDescription, setEventDescription] = useState('');
  const [dateOfEvent, setDateOfEvent] = useState('');

  const createEvent = async () => {
    try {
      const response = await fetch('YOUR_API_ENDPOINT/event/create/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          event_description: eventDescription,
          date_of_event: dateOfEvent,
        }),
      });

      const data = await response.json();

      if (response.ok) {
        Alert.alert('Success', data.message);
        setEventDescription('');
        setDateOfEvent('');
      } else {
        Alert.alert('Error', data.message || 'Failed to create event');
      }
    } catch (error) {
      console.error('Error creating event: ', error);
      Alert.alert('Error', 'Something went wrong. Please try again.');
    }
  };

  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <TextInput
        style={{ borderWidth: 1, borderColor: '#ccc', padding: 10, marginBottom: 10, width: '80%' }}
        placeholder="Event Description"
        value={eventDescription}
        onChangeText={setEventDescription}
      />
      <TextInput
        style={{ borderWidth: 1, borderColor: '#ccc', padding: 10, marginBottom: 10, width: '80%' }}
        placeholder="Date of Event"
        value={dateOfEvent}
        onChangeText={setDateOfEvent}
      />
      <Button title="Create Event" onPress={createEvent} />
    </View>
  );
}
